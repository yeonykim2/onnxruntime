var searchData=
[
  ['overriding_20malloc_162',['Overriding Malloc',['../overrides.html',1,'']]]
];

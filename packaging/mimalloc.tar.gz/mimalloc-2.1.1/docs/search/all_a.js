var searchData=
[
  ['typed_20macros_167',['Typed Macros',['../group__typed.html',1,'']]]
];

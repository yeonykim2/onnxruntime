var searchData=
[
  ['typed_20macros_322',['Typed Macros',['../group__typed.html',1,'']]]
];

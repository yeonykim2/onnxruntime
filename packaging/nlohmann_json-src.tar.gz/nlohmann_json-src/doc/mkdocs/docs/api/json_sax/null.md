# <small>nlohmann::json_sax::</small>null

```cpp
virtual bool null() = 0;
```

A null value was read.

## Return value

Whether parsing should proceed.

## Version history

- Added in version 3.2.0.


Kokoro Infrastructure
----------------------

The files in this directory serve as plumbing for running Protobuf
tests under Kokoro, our internal CI.

We have shared this part of our CI configuration in hopes that it is
helpful to contributors who want to better understand the details of
our test and release processes. If there are changes, please file an
issue; unfortunately, we may not be able to accept PRs (but feel free
to send one if it helps to explain the issue).

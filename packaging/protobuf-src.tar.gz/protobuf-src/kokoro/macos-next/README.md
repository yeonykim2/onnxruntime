# macOS-next

This builder is temporary for developing and testing builds using the "next"
macOS version without affecting the ordinary builds.

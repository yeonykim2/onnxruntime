
#pragma comment(lib, "Pathcch.lib")
#pragma comment(lib, "RuntimeObject.lib")
#pragma comment(lib, "Synchronization.lib")
#pragma comment(lib, "RpcRt4.lib")

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

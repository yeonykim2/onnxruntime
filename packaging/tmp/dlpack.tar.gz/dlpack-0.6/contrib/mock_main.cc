// Copyright by contributors
#include <dlpack/dlpack.h>
#include <dlpack/dlpackcpp.h>

int main() {
  dlpack::DLTContainer c;
  return 0;
}

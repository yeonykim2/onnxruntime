
onnx.checker
============


CheckerContext
++++++++++++++

.. autoclass:: onnx.checker.DEFAULT_CONTEXT
    :members:

check_value_info
++++++++++++++++

.. autofunction:: onnx.checker.check_value_info

check_tensor
++++++++++++

.. autofunction:: onnx.checker.check_tensor

check_attribute
+++++++++++++++

.. autofunction:: onnx.checker.check_attribute

check_node
++++++++++

.. autofunction:: onnx.checker.check_node

check_function
++++++++++++++

.. autofunction:: onnx.checker.check_function

check_graph
+++++++++++

.. autofunction:: onnx.checker.check_graph

check_model
+++++++++++

.. autofunction:: onnx.checker.check_model

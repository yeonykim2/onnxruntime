onnx.printer
============


to_text
+++++++

.. autofunction:: onnx.printer.to_text

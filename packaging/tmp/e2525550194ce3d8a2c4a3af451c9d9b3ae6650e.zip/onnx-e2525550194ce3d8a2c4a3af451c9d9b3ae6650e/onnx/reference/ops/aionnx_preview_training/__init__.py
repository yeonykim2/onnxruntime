# Copyright (c) ONNX Project Contributors

# SPDX-License-Identifier: Apache-2.0

from onnx.reference.ops.aionnx_preview_training._op_list import load_op
from onnx.reference.ops.aionnx_preview_training._op_run_training import OpRunTraining

This directory contains syntax highlighting and configuration files for editors
to properly display Protocol Buffer files.

See each file's header comment for directions on how to use it with the
appropriate editor.

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#if !defined __GNUC__
// #pragma warning( disable: 4571 4820 4514 4987 4710 4309 4986 4548 4189)
// relative include path contains '..'
#pragma warning( disable: 4464 )
#else
// #pragma GCC diagnostic ignored "-Wunused-variable"
#endif

#include "../SafeInt.hpp"
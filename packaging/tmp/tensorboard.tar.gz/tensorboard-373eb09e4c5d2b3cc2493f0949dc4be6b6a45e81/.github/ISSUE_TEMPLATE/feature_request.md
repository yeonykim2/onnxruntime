---
name: Feature request
about: Suggest an enhancement to TensorBoard
title: ''
labels: ''
assignees: ''

---

Please describe the problem that you’re facing and the enhancements that
you’d like to see. Feel free to include screenshots or code samples.

# wit-widget: What-If Tool JupyterLab extension

This npm package is for using the [What-If Tool](https://pair-code.github.io/what-if-tool/) as a JupyterLab extension.

For more information, see the [What-If Tool documentation](https://github.com/tensorflow/tensorboard/blob/master/tensorboard/plugins/interactive_inference/README.md).

What-If Tool Notebook Widget

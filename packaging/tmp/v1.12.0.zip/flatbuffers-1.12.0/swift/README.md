FlatBuffers swift can be found in both SPM

`.package(url: "https://github.com/mustiikhalil/flatbuffers.git", .branch("swift"))`

and Cocoapods

`pod 'FlatBuffers', :git => 'https://github.com/mustiikhalil/flatbuffers.git' :branch => 'swift'`

To report any error please use the main repository.


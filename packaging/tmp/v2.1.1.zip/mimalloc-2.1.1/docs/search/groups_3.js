var searchData=
[
  ['extended_20functions_317',['Extended Functions',['../group__extended.html',1,'']]]
];

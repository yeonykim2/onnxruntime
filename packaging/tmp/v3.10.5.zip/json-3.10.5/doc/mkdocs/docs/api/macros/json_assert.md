# JSON_ASSERT(x)

```cpp
JSON_ASSERT(x)
```

## Default implementation

```cpp
assert(x);
```
